package com.vitalik.itprogerapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    private TextView resultTextView;
    private EditText  number_field_1, number_field_2;
    private Button button_plus, button_1 , button_2, button_new_activity;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        resultTextView = findViewById(R.id.textView);
        number_field_1 = findViewById(R.id.hint_1);
        number_field_2 = findViewById(R.id.hint_2);
        button_plus = findViewById(R.id.button_plus);
        button_1 = findViewById(R.id.button);
        button_2 = findViewById(R.id.button2);
        button_new_activity = findViewById(R.id.button3);

        TextView main_text = findViewById(R.id.textView);
        Button button_1 = findViewById(R.id.button);
        button_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 showInfo(main_text.getText().toString(), button_1);
            }
        });



        button_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showInfoAlert("Привет");
            }
        });


        button_plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float num_1 = Float.parseFloat(number_field_1.getText().toString());
                float num_2 = Float.parseFloat(number_field_2.getText().toString());
                float res = num_1 + num_2;
                resultTextView.setText(String.valueOf(res));


            }
        });



    }

    public void startNewActivity(View v){
        Intent intent = new Intent(this, MainActivity_2.class);
        startActivity(intent);
    }

    public void btnClick(View v){

        showInfo(((Button)v).getText().toString(), (Button) v);

    }

    private void showInfo_1(String text_button, String text_toast, Button btn, Color color){
        btn.setText(text_button);

        Toast.makeText(this, text_toast, Toast.LENGTH_SHORT).show();
        //showInfoAlert("Ну погоди");
    }

    private void showInfo(String text, Button btn){
        btn.setText("Садик");
        btn.setBackgroundTintList(ColorStateList.valueOf(Color.GREEN));
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();

    }

    private void showInfoAlert(String text){

        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Мама")
                .setMessage("Не обижают в садике?")
                .setCancelable(false)
                .setPositiveButton("Вообще не могу тут", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        showInfo_1("Не плачь",
                                "Еду, жди, не плачь",
                                button_plus, Color.valueOf(122,122,122) );
                    }
                })
                .setNegativeButton("Нет, все меня боятся", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        showInfo_1("Ну погоди",
                                "Дома поговорим!",
                                button_plus, Color.valueOf(122,122,122) );
                    }
                });

        AlertDialog dialog = builder.create();
        dialog.show();
    }





}